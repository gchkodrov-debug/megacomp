FREE Teacher Cut-File Starter — OneJobKits

Six designs from the Teacher Cut-File & Classroom Decor Pack: letters A, B and C (layered), the WELCOME label,
the STAR STUDENT badge and a star decor shape — each in SVG, DXF and transparent PNG.
Upload the SVG to Cricut Design Space or Silhouette Studio; layers arrive named. Cut layer-2 first, face second.

The full pack: 63 designs Standard ($19) / 112 designs Bundle ($29) — full alphabet in two styles, 12 labels,
8 reward badges, 4 name-tag frames, 10 decor shapes. OneJobKits on Gumroad + Etsy.

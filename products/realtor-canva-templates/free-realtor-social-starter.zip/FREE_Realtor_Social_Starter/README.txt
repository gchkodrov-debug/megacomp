FREE Realtor Social Starter — OneJobKits

Three Canva-ready posts (Just Listed, Just Sold, Open House), each as PNG (post it now) and SVG (edit it in Canva).
Upload the SVG to Canva, drop in your photo, replace the [brackets], post. Real client words and real MLS numbers only —
the full kit's usage guide explains why, and it's the part that keeps your licence safe.

The full Realtor Canva Marketing Kit has 40 designs — posts, stories, a market-update carousel, flyers, postcards,
a door hanger and business cards — $39 / Pro $59 at OneJobKits.
